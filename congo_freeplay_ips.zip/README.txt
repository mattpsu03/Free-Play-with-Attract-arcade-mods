Congo Bongo (MAME "congo", rev C) - Free Play with attract mode
Apply each .ips to the matching original ROM from congo.zip:
  congo_rev_c_rom1.u21.ips  -> congo_rev_c_rom1.u21  (orig CRC 09355b5b)
  congo_rev_c_rom4.u24.ips  -> congo_rev_c_rom4.u24  (orig CRC 5332b9bf)
Other ROMs are unchanged.

Set Coin A to 3 coins/1 credit to enable free play:
 - attract mode runs; P1/P2 start begins a 1P/2P game at any time
 - coins ignored; INSERT COIN / CREDIT text replaced with FREE PLAY
 - lives DIP (incl. unlimited) works as original
All other coin settings behave as the original game.
