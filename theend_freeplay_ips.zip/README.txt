The End (Konami 1980) - Free Play patch
=======================================

Apply each IPS to the matching ROM from the stock MAME "theend" set:

  Patch          ROM           Stock CRC32   Patched CRC32
  ic13_1t.ips    ic13_1t.bin   93e555ba      d59a7f55
  ic14_2t.ips    ic14_2t.bin   2de7ad27      283f02bb
  ic18_6t.ips    ic18_6t.bin   dc4cc786      c4254756

All other ROMs are unchanged.

Usage: set Coinage DIP to "3 Coins / 1 Credit" to enable Free Play.
- Attract mode runs; credit / insert coin text reads FREE PLAY
- P1 START = 1-player game, P2 START = 2-player game
- Coins are ignored (coin meter still pulses); game over returns to attract
Other coinage settings behave exactly like the original game.
