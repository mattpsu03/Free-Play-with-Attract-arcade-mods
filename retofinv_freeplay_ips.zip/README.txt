Return of the Invaders (MAME set: retofinv) - Free Play with Attract Mode
=========================================================================

Apply each IPS patch to the matching stock ROM from retofinv.zip:

  a37__03.ic70.ips  ->  a37__03.ic70   (stock CRC32 eae7459d -> patched a6136a5a)
  a37__01.ic72.ips  ->  a37__01.ic72   (stock CRC32 505dd20b -> patched 99b40185)

All other ROMs in the set are unchanged.

Usage: set DSW-A switch 3 (the game's existing Free Play DIP) to ON.
 - Attract mode runs its full cycle (title, enemy intro, demo play, high scores).
 - "INSERT COIN(S)" screen and the credit line show FREE PLAY.
 - P1 START = 1-player game, P2 START = 2-player game, any time during attract.
 - Coins are ignored while Free Play is on.
 - After game over the game returns to attract with FREE PLAY restored.
With the DIP OFF the game behaves exactly like stock coin play.

The game's boot ROM checksum and its in-game ROM integrity check are both
kept valid by correction bytes at 0x1FFF (ic70) and 0x1FFF (ic72).
