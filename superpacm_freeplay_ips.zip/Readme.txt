Midway Super Pac-Man freeplay with attract  (superpacm)

Set Coin A to 3 Coins/1 Credit to enable Freeplay