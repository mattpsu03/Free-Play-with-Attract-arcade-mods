Pac N Pal freeplay with attract  (pacnpal)

Set Coin A to 3 Coins/1 Credit to enable Freeplay