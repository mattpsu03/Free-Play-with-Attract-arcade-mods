Pac N Pal Freeplay with Attract 

This is for the pacnpal ROMset.

Set the dipswitch to Coins 3/Credit 1 to enable Freeplay mode


Apply the IPS patches to the pacnpal ROMset