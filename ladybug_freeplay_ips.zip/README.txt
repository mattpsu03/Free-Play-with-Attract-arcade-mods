Lady Bug (Universal 1981, MAME set "ladybug") - Free Play attract mod
======================================================================

Apply each patch to the matching stock ROM file from ladybug.zip:

  File    Patch         Stock CRC32   Patched CRC32
  l1.c4   l1.c4.ips     d09e0adb      4d13a6be
  l2.d4   l2.d4.ips     88bc4a0a      a19c37bb
  l3.e4   l3.e4.ips     53e9efce      c06725c2
  l4.h4   (none)        ffc424d7      unchanged
  l5.j4   l5.j4.ips     ad6af809      aeb54abb
  l6.k4   l6.k4.ips     cf1acca4      141d591a

Graphics ROMs (l0.h7, l7.m7, l8.l7, l9.f7) and PROMs (10-1.f4, 10-2.k1,
10-3.c4) are unchanged.

With the Free Play DIP switch ON:
  - Attract mode runs (title, demo, hi-score screen) instead of the
    static "push button" screen
  - P1 or P2 Start begins a 1- or 2-player game from anywhere in attract
  - "TODAY'S HI SCORE" table is shown after the gameplay demo
  - Title screen shows FREE PLAY; coin ratio and LEFT/RIGHT text removed
  - Credit field shows FREEPLAY
  - Game over returns to attract mode

With Free Play OFF the game behaves as stock.
The program ROM checksum is preserved (no ROM error on boot).

Note: MAME will report the patched set as having incorrect CRCs; run it
from a separate folder/name or ignore the warning.
