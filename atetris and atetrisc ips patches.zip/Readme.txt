Additions to Tetris (atetris):

-First unused DIP switch enables/disables the level select screen (on is enable)
-Second unused DIP switch enables/disables continues (on is enable)

Apply the IPS patches to the original atetris ROMset.



Additions to Tetris cocktail version (atetrisc)

-Unused DIP switch enables disables both the level select screen and continues (on is enable)