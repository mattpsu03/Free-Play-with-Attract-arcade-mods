Thief (Pacific Novelty 1981, MAME "thief") - Free Play with attract mode
=======================================================================
Apply each patch to the matching stock ROM from thief.zip:

  t8a0ah0a.ips -> t8a0ah0a   (stock CRC edbbf71c -> patched CRC aebe4e95)
  t606bh12.ips -> t606bh12   (stock CRC 4ca2748b -> patched CRC f7323f09)

All other ROMs are unchanged.

Free Play = DSW1 switch 5 (0x10, first "Unused" DIP) ON.
  - Attract mode keeps running; coins are ignored
  - P1 / P2 start begins a 1- or 2-player game instantly at any point in attract
  - "FREE PLAY" shown on the THIEF title screen and the GAME OVER screen
DIP OFF = original coin behaviour.
