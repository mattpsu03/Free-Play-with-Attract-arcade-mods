Vs. RBI Baseball Freeplay with Attract

3 Coins/1 Credit for Freeplay mode