Dig Dug II Freeplay with Attract (digdug2)

This is for the digdug2 ROMset.

Set the dipswitch to Coins 3/Credit 1 to enable Freeplay mode


Apply the IPS patches to the digdug2 ROMset