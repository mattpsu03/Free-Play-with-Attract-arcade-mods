Super Space Invaders '91 Freeplay with Attract 

This is for the ssi ROMset.

Set the dipswitch to Coins 3/Credit 1 to enable Freeplay mode


Apply the IPS patches to the ssi ROMset