Journey (Bally Midway 1983, MAME journey) - Free Play with attract mode
Apply to the stock MAME journey ROMs:
  d2.ips -> d2  (CRC32 f2618913)
  d6.ips -> d6  (CRC32 5d445c99)
All other ROMs are unchanged.

Enable: Service mode > 5 Machine Setup > Coin Chute 1 = 1 coin for 9 credits.
- Attract mode runs normally; bottom line shows FREEPLAY PRESS 1 OR 2 PLAYER
- P1/P2 start begins a 1- or 2-player game immediately
- Buy-in (if enabled) prompts PRESS 1 OR 2 PLAYER instead of INSERT COIN
- Any other coin setting behaves as stock
ROM checksums are balanced so the boot ROM test passes.
Patched files will no longer match MAME's CRCs (MAME will warn but run).
