Gaplus Freeplay with Attract


Change Coin A to 3 Coins/1 Credit to activate freeplay

Apply the IPS patches to the "gaplus" romset