Phozon Freeplay with Attract (phozon)

This is for the phozon ROMSET.

Set the dipswitch to Coins 3/Credit 1 to enable Freeplay mode

Japanese text has been translated to English.

Apply the IPS patches to the phozon ROMset