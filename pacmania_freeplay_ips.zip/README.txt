Pacmania Freeplay with Attract

In service mode, change FREE to ON for freeplay