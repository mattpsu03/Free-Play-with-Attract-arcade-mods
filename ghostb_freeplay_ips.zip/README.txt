The Real Ghostbusters (Data East 1987) - Free Play with Attract Mode
MAME set: ghostb  (The Real Ghostbusters, US 2 Players, revision 2)
=====================================================================

WHAT IT DOES
------------
The stock game has no free play setting. This patch adds one, switched by
DIP switch SW1 bit 3 (DSW0 bit 0x04). In MAME, that switch is listed as
"Unused" at SW1:4 in the DIP switch menu. Set it to "On" to enable free play.

With free play ON:
  - Attract mode runs normally: title, instructions, demo play and the
    high score table.
  - P1 or P2 Start begins a game immediately from anywhere in attract,
    including the demo. Pressing both starts a 2-player game.
  - The other player can press Start at any time to join mid-game.
  - Pressing Start during the CONTINUE countdown continues for free.
  - Game over returns to attract.
  - "INSERT COIN" (flashing in attract), the bottom "CREDIT-xx" line and
    the top-of-screen "INSERT COIN !" for an empty player slot all read
    "FREE PLAY".
  - Pressing Start while a player is already alive does nothing. In the
    stock game this spends a credit to add lives and time, which would
    mean unlimited lives under free play.

With free play OFF (switch at its default), the game behaves exactly as
stock: coins, credits and "INSERT COIN" all work normally.

The "COIN / LIFE / ENERGY" price table in the attract instructions is
left unchanged.


FILES
-----
  dz01-22.1d.ips   main CPU fixed ROM ($8000-$FFFF)
  dz04-21.6d.ips   banked ROM (bank A holds the text/HUD routines)
  dz05-21.7d.ips   banked ROM (new code placed in unused bank D)

The MCU (dz-1.1b), sound, graphics and PROM files are not changed.


APPLYING
--------
Apply each IPS to the matching file from a stock ghostb.zip with any IPS
tool (Lunar IPS, Floating IPS, etc.), then re-zip all 22 files as ghostb.zip.


MAME will warn about wrong checksums for these three files. This is
expected; the game runs fine.



