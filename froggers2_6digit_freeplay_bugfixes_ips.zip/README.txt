froggers2 (Frogger, Sega set 2) - SNESNESCUBE64's free play/attract + philmurr bugfixes + 6-digit scores
Apply each .ips to the matching file from the STOCK MAME froggers2 set.


hiscore.dat entry:

froggers2:
@:maincpu,program,83ef,2,63,04
@:maincpu,program,83f1,a,63,01
@:maincpu,program,8742,6,00,00
