Hyper Pacman (hyperpac) - Free Play + Continue option patches

Apply to the original MAME hyperpac set files:
  hyperpac.h12.ips -> hyperpac.h12  (original CRC 2cf0531a, patched CRC 6c7269d8)
  hyperpac.i12.ips -> hyperpac.i12  (original CRC 9c7d85b8, patched CRC 741ccb6f)

DIP settings (DSW2, previously unused):
  SW2:1  On = Free Play (attract runs, P1/P2 start begins a game, FREE PLAY text)
         Off = normal coin play
  SW2:2  On = Continues enabled
         Off = Continues disabled

Note: "On" follows MAME's DIP menu for bank 2. On a real PCB these two
switches read in the opposite sense.
