Bal Cube (Metro 1996, MAME "balcube") - Free Play / Direct Start / English Text patch
======================================================================================

Apply each .ips to the matching file from the stock MAME balcube.zip:

  bal-cube_01.1.ips -> bal-cube_01.1   (graphics: in-game hint bubble redrawn in English)
  bal-cube_02.2.ips -> bal-cube_02.2   (graphics)
  bal-cube_03.3.ips -> bal-cube_03.3   (graphics)
  bal-cube_04.4.ips -> bal-cube_04.4   (graphics)
  bal-cube_05.5.ips -> bal-cube_05.5   (68000 program, odd bytes)
  bal-cube_06.6.ips -> bal-cube_06.6   (68000 program, even bytes)

bal-cube_07.7 and yrw801-m are unchanged.

Stock CRCs:   01 0ea3d161  02 492ca8f0  03 eef1d3b4  04 d1acda2c  05 15313e3f  06 c400f84d
Patched CRCs: 01 9ac43571  02 3aa63c91  03 bdc9f985  04 d786fd60  05 af56a015  06 2aa2fd5d

Changes
-------
* Free play (Coin A = Free Play): fixes the bug where the game faked a start
  press at boot, sat on the PRESS START title, then force-started a game.
  Free play now runs the full attract loop, same as coin mode.
* Free play: P1 START = 1-player game, P2 START = 2-player game
  (MODE SELECT screen skipped). Coin play is unchanged.
* Tutorial demo speech bubbles use Metro's built-in (unused) English set.
* In-game "基本は上でがんばれ!" hint bubble redrawn as "Basically, stay up top!".
* The boot ROM self-test still reports all six ROMs OK (checksums balanced
  in unused space). MAME will warn about CRC mismatches, which is expected.
