Gorf (MAME set: gorf) - Free Play with attract mode
====================================================

Apply each patch to the matching ROM from the stock gorf.zip:
  gorf-b.ips -> gorf-b.bin
  gorf-d.ips -> gorf-d.bin
  gorf-h.ips -> gorf-h.bin
(gorf-a, c, e, f, g are unchanged.)

With the Free Play DIP (S1:7) ON:
  - Attract mode runs the full cycle, same as coin mode
  - P1 start = 1-player game, P2 start = 2-player game, immediately
  - 3 ships per player (or 2 with the Lives DIP set to 2), instead of 6
  - "INSERT COIN" on the title screen reads "FREE PLAY"
With Free Play OFF the game behaves exactly like stock.

ROM checksums are balanced, so the board's ROM self-test still passes.
