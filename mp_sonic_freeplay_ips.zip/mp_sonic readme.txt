Sonic The Hedgehog (Mega Play) - mp_sonic - no-continue + hiscore fix
=====================================================================

WHAT THE PATCH DOES
  - Removes the continue screen. After the last life is lost the game goes
    GAME OVER -> high score name entry (only if your score made the table) ->
    back to the attract loop. "Continue?" is never offered.

FILES (apply each IPS to the matching file from mp_sonic.zip)
  ep15177.ic2.ips  ->  ep15177.ic2   CRC32 a389b03b -> 3b671c89
  ep15176.ic1.ips  ->  ep15176.ic1   CRC32 d180cc21 -> 4afa3ab1
  ep15175-01.ic3   ->  unchanged     CRC32 99246889

  The two program ROMs are byte-interleaved (ic2 = even bytes, ic1 = odd
  bytes), so each chip gets its own patch.

  For free play with the full attract sequence, also use the patched Mega Play
  BIOS (megaplay_bios_freeplay_ips.zip).

HISCORE.DAT ENTRY
  Stock hiscore.dat has no working entry for this game. Add this one
  (e.g. after the ;@s:sega/megatech.cpp section):

;@s:sega/megaplay.cpp

;******Sonic The Hedgehog (Mega Play)
;scores live in the Mega Play BIOS board RAM ($A02000 window); the BIOS clears that RAM
;and restarts the 68000 about 3.6s after power-on, so the restore has to wait until after that
mp_sonic:
@:maincpu,program,a02700,72,88,00
@delay=5

WHY THE DELAY IS NEEDED
  The score table is not in the Genesis work RAM; it is in the Mega Play BIOS
  board's battery RAM (68000 address $A02700: checksum, signature, then the
  10-entry table at $A02722). MAME does not save that RAM. At power-on the game
  writes its default table, then ~0.1s later the BIOS clears the RAM and resets
  the 68000, which rewrites the defaults. Without @delay the plugin restores
  your scores too early, they get wiped, and on exit the plugin saves the
  default table over your .hi file. @delay=5 restores after that reset.
  The entry covers the checksum and signature too, so the restored block stays
  valid.

  If you already have an mp_sonic.hi from an earlier attempt, delete it - it
  most likely only holds the default table.
