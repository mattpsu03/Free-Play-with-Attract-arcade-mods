Sega Mega Play BIOS - free play runs the full attract sequence
==============================================================

WHAT THE PATCH DOES (free play only - coin play is unchanged)
  - Stock BIOS treats free play as "always credited": after the Mega Play logo
    it jumps to PUSH START and the game sits on its title screen.
  - Patched: the logo, instruction pages and the game's own attract (title,
    demo, best scores) cycle exactly as in coin mode with no credits.
  - P1/P2 Start at any point in the attract starts a game with one press.
  - After game over it returns to the attract loop.

FILES (apply each IPS to the matching file from megaplay.zip)
  ep15294.ic2.ips     ->  ep15294.ic2     (Ver. 1, MAME default)  CRC32 aa8dc2d8 -> e0e03bf9
  epr-a15294.ic2.ips  ->  epr-a15294.ic2  (Ver. 2)                CRC32 f97c68aa -> 8e702583
  PLD files unchanged.

  Ver. 1 is tested in MAME with Sonic. Ver. 2 gets the same change at the
  matching code locations but is UNTESTED - MAME can't run Ver. 2 even unpatched.

DIP SETTING
  Free play needs BOTH coin banks (SW1 and SW2) set to free play (all four
  switches on each, DSW0 = $00). MAME labels the "Coin slot 2" free play setting
  as "1 coin/1 credit".

NOTES
  This is a BIOS change, so it applies to every Mega Play game. The one-press
  start relies on the game telling the BIOS its start screen is ready (Sonic
  does); a game that doesn't would need a second Start press.
