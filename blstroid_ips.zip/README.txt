Blasteroids (rev 4, MAME "blstroid") - Continues option + Free Play display patches
=====================================================================================

Apply these IPS patches to the stock MAME blstroid romset files:

  136057-4123.6c.ips  ->  136057-4123.6c   (stock CRC d14badc4  ->  patched CRC 3f638ae0)
  136057-4121.6b.ips  ->  136057-4121.6b   (stock CRC ae3e93e8  ->  patched CRC 3d06b968)

All other files in blstroid.zip are unchanged. The power-on ROM checksum
self-test is corrected, so the board boots normally.

What the patches do
-------------------
* Service menu > Game Options gets a new 7th item: CONTINUES ALLOWED  yes / no
  (default yes, so existing EEPROM settings behave like the stock game).

* With CONTINUES ALLOWED = no:
  - When a player runs out of ships it goes straight to GAME OVER: no
    "Want to continue?" panel, no "Press start to continue" text, no countdown.
    Qualifying scores still get high-score initials entry.
  - Players cannot join a game already in progress. The second player can
    still join during the opening warp-select screen to start a 2-player game.
    Once play is under way the idle player's panel is blank and start is ignored.

* With Coin Options > Bonus Adder = Free Play:
  - The bottom-of-screen "CREDITS n" is replaced by "FREE PLAY".
  - The "2 CREDIT=START / 1 CREDIT=CONT" text is no longer shown.
  - In coin modes the display is the same as stock.
