Make Trax (MAME: maketrax) - Free Play with Attract Mode
=========================================================

Apply each IPS patch to the matching stock ROM from maketrax.zip:

  maketrax.6e.ips  ->  maketrax.6e
  maketrax.6h.ips  ->  maketrax.6h

All other ROMs (6f, 6j, 5e, 5f, PROMs) are unchanged.

Stock ROMs (expected input):
  maketrax.6e  CRC32 0150fb4a  SHA1 ba41582d5432670654479b4bf6d938d2168858af
  maketrax.6h  CRC32 a2cdc51e  SHA1 80d80235cda3ce19c1dbafacf3d47b1325ad4728

Patched ROMs (expected output):
  maketrax.6e  CRC32 0fa18335  SHA1 ad4e9b5cbff2aafda119eee23a05dfa3ccc21626
  maketrax.6h  CRC32 77151b06  SHA1 811c124934c48492ad1fdcdbe41c4887b826e217

Usage:
  Set Coinage DIP to Free Play (both coinage bits off) and reset.
  - Attract mode runs normally instead of the static PUSH START screen.
  - P1 / P2 start a 1- or 2-player game at any time in attract (title or demo).
  - Bottom row shows "FREE PLAY" instead of "CREDIT 99".
  Coin settings behave exactly like the original game.
  Boot ROM checksum is preserved (self-test passes).
