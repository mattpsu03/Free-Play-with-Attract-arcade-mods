Jump Bug (MAME jumpbug) - True Free Play patch (v2)
Apply each .ips to the matching file in the stock jumpbug.zip:
  jb1.ips -> jb1   (CRC32 415aa1b7 -> eae9f117)
  jb4.ips -> jb4   (CRC32 66751d12 -> 675820e9)
  jb5.ips -> jb5   (CRC32 e2d66faf -> 8fdb2d6d)
Free play is enabled when the Coinage DIP is set to "A 2/1 B 2/1".
Attract mode runs until P1/P2 start; bottom line shows FREE PLAY.
Built-in ROM checksums (0000-3FFF, 8000-9F00) are preserved.
v2: fixed start press occasionally being dropped when attract restarts.
