Jump Bug (MAME jumpbug) - True Free Play patch
Apply each .ips to the matching file in the stock jumpbug.zip:
  jb1.ips -> jb1   (CRC32 415aa1b7 -> ea450083)
  jb4.ips -> jb4   (CRC32 66751d12 -> 98829853)
  jb5.ips -> jb5   (CRC32 e2d66faf -> 2da49f4f)
Free play is enabled when the Coinage DIP is set to "A 2/1 B 2/1".
Attract mode runs until P1/P2 start; bottom line shows FREE PLAY.
Built-in ROM checksums (0000-3FFF, 8000-9F00) are preserved.
