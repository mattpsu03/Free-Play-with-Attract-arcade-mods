patches guzz-01 and guzz-16 are for "guzzler" romset

guzz1.19 is only needed for the "guzzlers" set